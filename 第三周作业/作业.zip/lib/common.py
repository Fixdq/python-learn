#!/usr/bin/env python3
# encoding: utf-8
# by fixdq
"""
通用工具
"""


def generate_id():
    return


def color(msg):
    return "\033[1;31;43m{}\033[0m".format(msg)
